package app;
import java.util.Scanner;
public class Account {
    //Class variables
    private double checkingBalance;
    private double savingsBalance;
    private String accName;
    private int customerID;
    //private Account[] acc = {};
    Scanner sc = new Scanner(System.in);
    //Constructors
    public Account() {
        accName = "John Doe";
        customerID = 1234;
        checkingBalance = 0;
        savingsBalance = 1000;
    }
    public Account(String accName, int customerID, double checkingBalance, double savingsBalance) {
        this.accName = accName;
        this.customerID = customerID;
        this.checkingBalance = checkingBalance;
        this.savingsBalance = savingsBalance;
    }
    //Class Methods
    private void withdrawSavings(double amount) {
        if (this.savingsBalance > amount && amount > 0) {
            this.savingsBalance -= amount;
            System.out.println("Amount withdrawn: $" + amount);
            System.out.println("New balance: $" + this.savingsBalance);
        } else if (amount <= 0) {
            System.out.println("Not a valid input.");
        } else {
            System.out.println("Not enough money in account for this amount.");
        }
    }
    private void withdrawChecking(double amount) {
        if (this.checkingBalance > amount && amount > 0) {
            this.checkingBalance -= amount;
            System.out.println("Amount withdrawn: $" + amount);
            System.out.println("New balance: $" + this.checkingBalance);
        } else if (amount <= 0) {
            System.out.println("Not a valid input.");
        } else {
            System.out.println("Not enough money in account for this amount.");
        }
    }

    private void depositSavings(double amount) {
        if (amount > 0) {
            this.savingsBalance += amount;
            System.out.println("Amount deposited: $" + amount);
            System.out.println("New balance: $" + this.savingsBalance);
        } else {
            System.out.println("Not a valid amount.");
        }
    }
    private void depositChecking(double amount) {
        if (amount > 0) {
            this.checkingBalance += amount;
            System.out.println("Amount deposited: $" + amount);
            System.out.println("New balance: $" + this.checkingBalance);
        } else {
            System.out.println("Not a valid amount.");
        }
    }

    private void transaction(int selection) {
        double amount;
        while (selection != 4) {
            if (selection == 1) {
                System.out.println("1. Checking");
                System.out.println("2. Savings");
                int press = sc.nextInt();
                if (press == 1){
                    System.out.println(this.checkingBalance);
                } else if (press == 2) {
                    System.out.println(this.savingsBalance);
                }

            } else if (selection == 2) {
                System.out.println("1. Checking");
                System.out.println("2. Savings");
                int press = sc.nextInt();
                if (press == 1){
                    System.out.print("Enter amount to deposit: ");
                    amount = sc.nextDouble();
                    depositChecking(amount);
                } else if (press == 2) {
                    System.out.print("Enter amount to deposit: ");
                    amount = sc.nextDouble();
                    depositSavings(amount);
                }
            } else if (selection == 3) {
                System.out.println("1. Checking");
                System.out.println("2. Savings");
                int press = sc.nextInt();
                if (press == 1){
                    System.out.print("Enter amount to withdraw: ");
                    amount = sc.nextDouble();
                    withdrawChecking(amount);
                } else if (press == 2) {
                    System.out.print("Enter amount to withdraw: ");
                    amount = sc.nextDouble();
                    withdrawSavings(amount);
                }
            } else if (selection == 4) {
                break;
            } else {
                System.out.println("Not a valid input");
            }
            System.out.println("=========================================");
            System.out.println("Would you like to make another transaction?");
            System.out.println("Enter Y/N to continue");
            String cont = sc.next();
            if (cont.equals("y") || cont.equals("Y")) {
                display();
                selection = sc.nextInt();
            } else if (cont.equals("n") || cont.equals("N")) {
                System.out.println("Thank you for banking with us!");
                break;
            } else {
                System.out.println("Not a valid entry");
                break;
            }
        }
    }
    public void createAccount() {
        System.out.println("Welcome to Mountain Broker Bank");
        mountain();
        System.out.print("Please enter your first and last name: ");
        this.accName = sc.nextLine();
        System.out.println("Thank you for banking with us " + this.accName + "!");
        System.out.print("Please enter a custom 4-digit PIN: ");
        this.customerID = sc.nextInt();
        while (this.customerID >= 10000 || this.customerID <= 999) {
            System.out.println("Invalid length, please enter a 4 digit pin");
            this.customerID = sc.nextInt();
        }
        System.out.print("Please enter initial deposit to checking account: ");
        this.checkingBalance = sc.nextDouble();
        System.out.print("Please enter initial deposit to savings account: ");
        this.savingsBalance = sc.nextDouble();
        System.out.println("=========================================");
        System.out.println("Would you like to access this bank account?");
        System.out.println("Enter Y/N to continue");
        String cont = sc.next();
        if (cont.equals("y") || cont.equals("Y")) {
            access();
        } else if (cont.equals("n") || cont.equals("N")) {
            System.out.println("Thank you for banking with us " + this.accName);
        } else {
            System.out.println("Not a valid entry");
        }
    }
    //Run method in main
    public void access() {
        System.out.print("Enter your personal ID number: ");
        int iD = sc.nextInt();
        if (iD == this.customerID) {
            display();
            int selection = sc.nextInt();
            transaction(selection);
        }else{
            System.out.println("Invalid pin");
        }
    }
    public void printArray(Account[] account){
        System.out.println("Current accounts on file: ");
        System.out.println("=========================================");
        for (Account value : account) {
            System.out.println("Account Name: " + value.getAccName());
            System.out.println("Available Checking Balance: " + value.getCheckingBalance());
            System.out.println("Available Savings Balance: " + value.getSavingsBalance());
            System.out.println("=========================================");
        }
    }
    private void mountain(){
        System.out.println(" \t\t            ^");
        System.out.println(" \t\t      ^    ^^^  ");
        System.out.println(" \t\t     ^^^  ^^^^^ ^");
        System.out.println(" \t\t    ^^^^^^^^^^^^^^");
        System.out.println(" \t\t  ^^^^^^^^^^^^^^^^^^");
        System.out.println(" \t\t^^^^^^^^^^^^^^^^^^^^^^");
    }

    private void display() {
        System.out.println("=========================================");
        System.out.println("How can we be of service?");
        System.out.println("Enter a selection below");
        System.out.println("1. View balance");
        System.out.println("2. Deposit");
        System.out.println("3. Withdraw");
        System.out.println("4. End transaction");
    }

    public double getCheckingBalance() {
        return checkingBalance;
    }

    public void setCheckingBalance(double checkingBalance) {
        this.checkingBalance = checkingBalance;
    }

    public double getSavingsBalance() {
        return savingsBalance;
    }

    public void setSavingsBalance(double savingsBalance) {
        this.savingsBalance = savingsBalance;
    }

    public String getAccName() {
        return accName;
    }

    public void setAccName(String accName) {
        this.accName = accName;
    }

    public int getCustomerID() {
        return customerID;
    }

    public void setCustomerID(int customerID) {
        this.customerID = customerID;
    }
}



