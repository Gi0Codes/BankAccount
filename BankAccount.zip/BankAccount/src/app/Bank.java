package app;
public class Bank {
    public static void main(String[] args) {
        Account[] accounts;
        Account access = new Account();
        Account a1 = new Account();
        Account a2 = new Account();
        a1.createAccount();
    }
}

